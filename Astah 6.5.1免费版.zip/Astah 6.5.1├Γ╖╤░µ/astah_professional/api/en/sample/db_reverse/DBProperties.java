import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Properties;


public class DBProperties extends Properties {

	//for Installer
	private static final String FILE_NAME = "Config.properties";
	//from Eclipse
	//private static final String FILE_NAME = "api_sample\\db_reverse\\Config.properties";
	
	public static final String POINT = ".";
	
	public static final String URL = "URL";
	
	public static final String USER = "User";
	
	public static final String JDBC_DRIVER = "JDBC_Driver";
	
	public static final String DRIVER_PATH = "Driver_Path";
	
	public static final String CURRENT_DB = "Current_DB";
	
	public static final String TARGET_MODEL = "Target_Model";
	
	public static final String DB_TYPES = "DB_Types";
	
	public DBProperties() {
		super();
		load(FILE_NAME);
	}
	
	private void load(String fileName) {
        try {
            FileInputStream stream = new FileInputStream(FILE_NAME);
            load(stream);
            stream.close();
        } catch (Exception e) {
            // ignore case when there is no file.
        }
    }
	
	public String[] getDBTypes() {
		String types = getString(DB_TYPES);
		return types.split(",");
	}
	
	public String getCurrentDB() {
		return getString(CURRENT_DB);
	}
	
	public void setCurrentDB(String value) {
		setString(CURRENT_DB, value);
	}
	
	public String getURL(String dbType) {
		return getString(dbType + POINT + URL);
	}
	
	public void setURL(String dbType, String value) {
		if (value != null && !value.equals(getURL(dbType))) {
			setString(dbType + POINT + URL, value);
		}
	}
	
	public String getUser(String dbType) {
		return getString(dbType + POINT + USER);
	}
	
	public void setUser(String dbType, String value) {
		if (value != null && !value.equals(getUser(dbType))) {
			setString(dbType + POINT + USER, value);
		}
	}
	
	public String getJDBCDriver(String dbType) {
		return getString(dbType + POINT + JDBC_DRIVER);
	}
	
	public void setJDBCDriver(String dbType, String value) {
		if (value != null && !value.equals(getJDBCDriver(dbType))) {
			setString(dbType + POINT + JDBC_DRIVER, value);
		}
	}
	
	public String getDriverPath(String dbType) {
		return getString(dbType + POINT + DRIVER_PATH);
	}
	
	public void setDriverPath(String dbType, String value) {
		if (value != null && !value.equals(getDriverPath(dbType))) {
			setString(dbType + POINT + DRIVER_PATH, value);
		}
	}
	
	public String getTargetModel() {
		return getString(TARGET_MODEL);
	}
	
	public void setTargetModel(String value) {
		if (value != null && !value.equals(getTargetModel())) {
			setString(TARGET_MODEL, value);
		}
	}
	
	private String getString(String key) {
        return getProperty(key);
    }

    private void setString(String key, String value) {
        if (value == null) {
            return;
        }
        setProperty(key, value);
    }
    
    public void store() {
        try {
            OutputStream stream = new FileOutputStream(FILE_NAME);
            store(stream, null);
            stream.close();
        } catch (Exception e) {
        }
    }
}
